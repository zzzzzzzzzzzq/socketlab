#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int break_down(char *text, char *temp, int *pos, int size,int *t_size);